from prexview import PrexView

pxv = PrexView
options = dict(design='custom-invoice', output='html')

xml = '''<?xml version='1.0' encoding='UTF-8'?>
<Rows>
<Row><IdCp>1</IdCp> <Cp>Cp J Gondim</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>2</IdCp> <Cp>Cp Venus</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>3</IdCp> <Cp>Cp Cardoso</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>4</IdCp> <Cp>Cp Josefa Maria</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>5</IdCp> <Cp>Cp Cassia Reis</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>6</IdCp> <Cp>Cp Goncalves</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>7</IdCp> <Cp>Cp Eros</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>8</IdCp> <Cp>Cp Essencia</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>9</IdCp> <Cp>Cp Carbonell</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>10</IdCp> <Cp>Cp Nicia</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>11</IdCp> <Cp>Cp Carlos Possato</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>12</IdCp> <Cp>Cp Femina</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>13</IdCp> <Cp>Cp Cecita</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>14</IdCp> <Cp>Cp Noal</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>15</IdCp> <Cp>Cp Seiva Floral</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>16</IdCp> <Cp>Cp Cia das Marcas</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>17</IdCp> <Cp>Cp Lamane</Cp> <AnoVigente>2020</AnoVigente></Row>
<Row><IdCp>18</IdCp> <Cp>Cp Floresmel</Cp> <AnoVigente>2021</AnoVigente></Row>
<Row><IdCp>19</IdCp> <Cp>Cp Ofris</Cp> <AnoVigente>2021</AnoVigente></Row>
</Rows>'''

file = 'test_xml.html'

try:
    res = pxv.sendXML(self = None, content=xml, options={'design': 'custom-invoice', 'output': 'html'})

    with open(file, 'wb') as f:
        f.write(res['file'])
        f.close()

    print ('File created:', file)
except Exception as e:
    print (e)